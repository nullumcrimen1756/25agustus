-- File SQL untuk memperbaiki struktur tabel anggaran_pendapatan
-- Jalankan query ini di phpMyAdmin jika ada error

-- 1. Tambahkan kolom type jika belum ada
ALTER TABLE `anggaran_pendapatan` 
ADD COLUMN IF NOT EXISTS `type` ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL DEFAULT 'subkategori' AFTER `jumlah`;

-- 2. Hapus constraint unique lama jika ada
ALTER TABLE `anggaran_pendapatan` DROP INDEX IF EXISTS `unique_anggaran`;

-- 3. Tambahkan constraint unique yang baru dengan kolom type
ALTER TABLE `anggaran_pendapatan` 
ADD UNIQUE KEY `unique_anggaran` (`kode_subkategori`, `bulan`, `type`);

-- 4. Update data yang sudah ada dengan type default 'subkategori' jika kolom type masih NULL
UPDATE `anggaran_pendapatan` SET `type` = 'subkategori' WHERE `type` IS NULL OR `type` = '';

-- 5. Hapus data duplikat jika ada (sebelum unique key ditambahkan)
DELETE a1 FROM `anggaran_pendapatan` a1
INNER JOIN `anggaran_pendapatan` a2 
WHERE a1.id > a2.id 
AND a1.kode_subkategori = a2.kode_subkategori 
AND a1.bulan = a2.bulan 
AND a1.type = a2.type;

-- 6. Tampilkan struktur tabel setelah perbaikan
DESCRIBE `anggaran_pendapatan`;

-- 7. Tampilkan data yang ada
SELECT * FROM `anggaran_pendapatan` ORDER BY `type`, `kode_subkategori`;
