<?php
// views/footer.php
?>
    </div> <!-- Penutup container -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php if (isset($custom_scripts)) { echo $custom_scripts; } ?>
</body>
</html>
